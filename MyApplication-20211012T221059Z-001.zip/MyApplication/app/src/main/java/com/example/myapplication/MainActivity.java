package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity {

    EditText txtWords;
    TextView txtSize;
    Button btnBig;
    Button btnSmall;
    CheckBox cbxBold;
    CheckBox cbxItalik;
    CheckBox cbxUnderline;
    Spinner sColor;
    Spinner sFont;
    RadioButton rbRTL;
    RadioButton rbBottom;
    RadioButton rbLTR;
    EditText txtFileName;
    Button btnNew;
    Button btnGetFile;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtWords = (EditText) findViewById(R.id.txtWords);
        txtSize = (TextView) findViewById(R.id.txtSize);
        btnBig = (Button) findViewById(R.id.btnBig);
        btnSmall =(Button) findViewById(R.id.btnSmall);
        cbxBold =(CheckBox) findViewById(R.id.cbxBold);
        cbxItalik =(CheckBox) findViewById(R.id.cbxItalik);
        cbxUnderline =(CheckBox) findViewById(R.id.cbxUnderline);
        sColor = (Spinner) findViewById(R.id.spinnerColor);
        sFont = (Spinner) findViewById(R.id.spinnerFont);
        rbRTL = (RadioButton) findViewById(R.id.rbRTL);
        rbBottom= (RadioButton) findViewById(R.id.rbLTR);
        rbLTR = (RadioButton) findViewById(R.id.rbLTR);
        txtFileName = (EditText) findViewById(R.id.txtFileName);
        btnNew = (Button) findViewById(R.id.btnNew);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnGetFile = (Button) findViewById(R.id.btnGetFile);

        fillColors();
        fillFonts();

        btnBig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSize('+');
            }
        });

        btnSmall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSize('-');
            }
        });

        cbxBold.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setBold();
            }
        });

        cbxItalik.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setItalik();
            }
        });

        cbxUnderline.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setUnderline();
            }
        });

        sColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setOneColor();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sFont.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setOneFont();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        rbLTR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setAlign();
            }
        });
        rbBottom.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setAlign();
            }
        });
        rbRTL.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setAlign();
            }
        });

        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newFile();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFile();
            }
        });

        btnGetFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFile();
            }
        });
    }

    protected void fillColors(){
        String[] strColors ={
                "black",
                "red",
                "blue",
                "green",
                "gray",
                "orange",
                "navy",
                "brown",
                "pink",
                "yellow"

        };
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,strColors);
        sColor.setAdapter(adapter);

    }

    protected void fillFonts(){
        String[] strFonts = {
                "sans-serif",
                "arial",
                "bauhaus",
                "blackkadder",
                "broadway",
                "impact",
                "andalus",
                "cortoba",
                "digital",
                "jokerman"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,strFonts);
        sFont.setAdapter(adapter);
    }

    protected void setSize(char bigORsmall){
        int size = Integer.parseInt(txtSize.getText()+"");

        if(bigORsmall=='+') size++;
        else size--;

        if(size >60)size=60;
        if(size <10) size =10;
        txtWords.setTextSize(size);
        txtSize.setText(size+"");

    }

    protected void setBold(){

        setOneFont();
    }

    protected void setItalik(){
        if(cbxItalik.isChecked()){
            txtWords.setTypeface(null, Typeface.ITALIC);
        }
        else
        {
            txtWords.setTypeface(null, Typeface.NORMAL);
        }

    }

    protected void setUnderline(){
        if(cbxUnderline.isChecked()){
            txtWords.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        }
        else
        {
            txtWords.setPaintFlags(Paint.LINEAR_TEXT_FLAG);
        }
        setBold();
    }

    protected void setOneColor(){
        String strColor = sColor.getSelectedItem().toString();

        switch (strColor)
        {
            case "black":
                txtWords.setTextColor(getResources().getColor(R.color.black));
                break;
            case "red":
                txtWords.setTextColor(getResources().getColor(R.color.red));
                break;
            case "blue":
                txtWords.setTextColor(getResources().getColor(R.color.blue));
                break;
            case "green":
                txtWords.setTextColor(getResources().getColor(R.color.green));
                break;
            case "gray":
                txtWords.setTextColor(getResources().getColor(R.color.gray));
                break;
            case "orange":
                txtWords.setTextColor(getResources().getColor(R.color.orange));
                break;
            case "navy":
                txtWords.setTextColor(getResources().getColor(R.color.navy));
                break;
            case "brown":
                txtWords.setTextColor(getResources().getColor(R.color.brown));
                break;
            case "pink":
                txtWords.setTextColor(getResources().getColor(R.color.pink));
                break;
            case "yellow":
                txtWords.setTextColor(getResources().getColor(R.color.yellow));
                break;


        }
    }

    protected void setOneFont(){
        String strFont = sFont.getSelectedItem().toString();
        Typeface tf ;
          if ("sans-serif".equals(strFont))
              tf= Typeface.SANS_SERIF;
          else
             tf=Typeface.createFromAsset(getAssets(),strFont+".ttf");

         if(cbxBold.isChecked()) {
             txtWords.setTypeface(tf, Typeface.BOLD);

         }
        else
            txtWords.setTypeface(tf,Typeface.NORMAL);

    }

    protected void setAlign(){
        if(rbLTR.isChecked()) {
            txtWords.setGravity(Gravity.LEFT);
        }
            else if (rbRTL.isChecked())
                {
            txtWords.setGravity(Gravity.RIGHT);

        }
            else
            txtWords.setGravity(Gravity.CENTER_HORIZONTAL);

    }

    protected void newFile(){
        txtWords.setText("");
        txtSize.setText("14");
        txtWords.setTextSize(14);
        cbxBold.setChecked(false);
        cbxItalik.setChecked(false);
        cbxUnderline.setChecked(false);
        sColor.setSelection(0);
        sFont.setSelection(0);
        rbLTR.setChecked(true);
        txtFileName.setText("DosyaAdı");
        txtWords.requestFocus();
    }

    protected void saveFile(){
        if( "".equals(txtFileName.getText().toString().trim()) ){
            Toast.makeText(this,"Dosya Adı Boş Olamaz!", Toast.LENGTH_SHORT).show();
            txtFileName.requestFocus();

        }
        else
        {
            try {
            String strPath = Environment.getExternalStorageDirectory().getPath()+"/MyWords"; //bu dosya konumu değiş
            File f =new File(strPath);
            f.mkdir();
            PrintWriter pw = new PrintWriter(strPath+"/"+ txtFileName.getText().toString()+".txt");
            pw.write(txtWords.getText().toString());
            pw.close();
            PrintWriter pwset  = new PrintWriter(strPath+"/"+txtFileName.getText()+"Set.txt");
            String strSet = txtSize.getText()
                    +"\n"+cbxBold.isChecked()
                    +"\n"+cbxItalik.isChecked()
                    +"\n"+cbxUnderline.isChecked()
                    +"\n"+sColor.getSelectedItem()
                    +"\n"+sFont.getSelectedItem()
                    +"\n"+rbLTR.isChecked()
                    +"\n"+rbRTL.isChecked();
            pwset.write(strSet);
            pwset.close();
            Toast.makeText(this,"Dosya Kayıt Edildi.",Toast.LENGTH_SHORT).show();

            } catch (FileNotFoundException e) {
                Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
    }

    protected void getFile(){
        try{
            String strPath = Environment.getExternalStorageDirectory().getPath() + "/MyWords/";
            FileReader fr =new FileReader(strPath+txtFileName.getText() + ".txt");
            BufferedReader br = new BufferedReader(fr);
            String strContent ="";
            String line = "";
            while((line = br.readLine())!=null){
                strContent+=line + "\n";

            }
            fr = new FileReader(strPath + txtFileName.getText() + "Set.txt");
            br = new BufferedReader(fr);
            String [] strSet  = new String[8];
            int x = 0;
            while ( (line = br.readLine())!=null )
            {
                strSet[x] = line ;
                x++;

            }
            fr.close();
            br.close();


            txtSize.setText(strSet[0]);
            txtWords.setTextSize(Integer.parseInt(strSet[0]));
            cbxBold.setChecked(Boolean.parseBoolean(strSet[1]));
            cbxItalik.setChecked(Boolean.parseBoolean(strSet[2]));
            cbxUnderline.setChecked(Boolean.parseBoolean(strSet[3]));
            sColor.setSelection( ((ArrayAdapter<String>)sColor.getAdapter()).getPosition(strSet[4]) );
            sFont.setSelection( ((ArrayAdapter<String>)sFont.getAdapter()).getPosition(strSet[5]) );
            if ("true".equals(strSet[6])) rbLTR.setChecked(true);
            else rbRTL.setChecked(true);

            txtWords.setText(strContent);
        }
        catch (Exception e)
        {
        Toast.makeText(this, e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
}
